#include <8051.h>

void main() 
{ 
    unsigned char i, j;

    unsigned char massiv[11] = 
    { 
        0xC0, // 0
        0xF9, // 1
        0xA4, // 2
        0xB0, // 3
        0x99, // 4
        0x92, // 5
        0x82, // 6
        0xF8, // 7
        0x80, // 8
		0x90  // 9
    };
    unsigned char sequence[8] = {5, 4, 6, 3, 7, 2, 8, 1};
    unsigned char sequence2[10] = {0,1,2,3,4,5,6,7,8,9};

	P2 = 0xFF;
    P3 = 0;
    while(1)
    {   
		
        if((P3 && 0x01) == 1)
        {

            for(i = 0; i < 8; i++)
            {
				
                P2 = massiv[sequence[i]];
                
                for(j = 0; j < 200; j++); //hold time for visibility digits
				if (P3 == 0)
				break;
            }
			if (P3 == 0)
			break;
        }
		else
        {

            for(i = 0; i < 10; i++)
            {
                P2 = massiv[sequence2[i]];
                for(j = 0; j < 200; j++);
				if (P3 == 1)
				break;
            }
			if (P3 == 1)
			break;
    }
    }
}