#include <8051.h>
#include <stdio.h>
void number(unsigned int i, unsigned int j)
{
unsigned char massiv[4][4] = {
        {'+','9','8','7'},
        {'-','6','5','4'},
        {'*','3','2','1'},
        {'/','=','0','C'}};

        P0 = massiv[i][j]; 
        P2 = 0x1; 
        P2 = 0x2;     
} 

void delay(unsigned int num){
    unsigned int i;
    for(i = 0; i<=num; i++);
}
void main()
{
    unsigned int i,j,a,b;   
 
    P0 = 0x38;  
    P2 = 0x1;  
    P2 = 0x0;  
    P0 = 0x80;  
    P2 = 0x1;  
    P2 = 0x0; 
     
    //first_line();    
    while(1)
    { 
        a = 0;
        b = 0;
        for (i = 0; i < 4; i++){
            P3 = 0xff-(0x1<<i);

            for (j = 0; j < 4; j++){
                
                if(P1 != 0xff)
                {
                    if(P1 == (0xff-(0x1<<j)))
                    {
                        number(j,i);
                    }
                }

            }

        }
    }  

}