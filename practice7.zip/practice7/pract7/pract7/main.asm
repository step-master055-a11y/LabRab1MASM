; ============================================
; PWM CONTROLLER WITH BUTTON INTERRUPTS FOR MULTISIM
; Timer 2 generates PWM signal on P1.0
; INT0 (P3.2) and INT1 (P3.3) control duty cycle
; Duty cycle steps: 25%, 35%, 45%, 55%
; ============================================

ORG 0000H
    LJMP 0100H

; ============================================
; INTERRUPT VECTORS
; ============================================

ORG 0003H                     ; INT0 VECTOR (P3.2) - BUTTON PLUS
    LJMP 0300H                ; Jump to button plus handler

ORG 0013H                     ; INT1 VECTOR (P3.3) - BUTTON MINUS
    LJMP 0400H                ; Jump to button minus handler

ORG 002BH                     ; TIMER 2 INTERRUPT VECTOR
    LJMP 0200H                ; Jump to PWM generator

; ============================================
; MAIN PROGRAM INITIALIZATION
; ============================================

ORG 0100H
    MOV 81H, #70H             ; Initialize Stack Pointer (SP = 70H)
    
    ; === BUTTON CONFIGURATION ===
    SETB 0B2H                 ; Set P3.2 as input with pull-up (button +)
    SETB 0B3H                 ; Set P3.3 as input with pull-up (button -)
    
    ; === VARIABLE INITIALIZATION ===
    MOV 32H, #3               ; STEP = 3 (starting position, 55% duty cycle)
    MOV 30H, #55              ; DUTY = 55% (current duty cycle value)
    MOV 31H, #0               ; COUNT = 0 (PWM period counter 0-99)
    
    ; === EXTERNAL INTERRUPT CONFIGURATION FOR BUTTONS ===
    MOV 88H, #05H             ; TCON = 05H (binary 00000101)
                              ; IT0 = 1 (INT0 triggers on falling edge)
                              ; IT1 = 1 (INT1 triggers on falling edge)
    
    ; === TIMER 2 CONFIGURATION (PWM PERIOD ~0.06ms) ===
    MOV 0C8H, #00H            ; T2CON = 00H (Timer 2 in auto-reload mode)
    MOV 0CAH, #212            ; RCAP2L = 212 (reload value low byte)
    MOV 0CBH, #253            ; RCAP2H = 253 (reload value high byte)
    MOV 0CCH, #212            ; TH2 = 212 (timer high byte)
    MOV 0CDH, #253            ; TL2 = 253 (timer low byte)
    
    ; === INTERRUPT ENABLE CONFIGURATION ===
    MOV 0A8H, #0A7H           ; IE = A7H (binary 10100111)
                              ; EA  = 1 (global interrupt enable)
                              ; ET2 = 1 (enable Timer 2 interrupt)
                              ; EX1 = 1 (enable INT1 - button -)
                              ; EX0 = 1 (enable INT0 - button +)
    
    ; === START TIMER 2 ===
    MOV 0C8H, #04H            ; T2CON = 04H (set TR2 = 1 to start timer)

; ============================================
; MAIN LOOP - UPDATE DUTY CYCLE BASED ON STEP VALUE
; ============================================

MAIN_LOOP:
    MOV A, 32H                ; Load STEP value into accumulator
    CJNE A, #0, L1            ; Compare with 0, jump if not equal
    MOV 30H, #25              ; STEP = 0 -> DUTY = 25%
    SJMP MAIN_LOOP            ; Repeat loop
    
L1: CJNE A, #1, L2           ; Compare with 1, jump if not equal
    MOV 30H, #35              ; STEP = 1 -> DUTY = 35%
    SJMP MAIN_LOOP            ; Repeat loop
    
L2: CJNE A, #2, L3           ; Compare with 2, jump if not equal
    MOV 30H, #45              ; STEP = 2 -> DUTY = 45%
    SJMP MAIN_LOOP            ; Repeat loop
    
L3: MOV 30H, #55             ; STEP = 3 -> DUTY = 55% (default)
    SJMP MAIN_LOOP            ; Repeat loop

; ============================================
; TIMER 2 INTERRUPT SERVICE ROUTINE
; Generates PWM signal on P1.0 (bit address 90H)
; Period = 100 interrupts = 100 * 0.06ms = 6ms (166 Hz)
; ============================================

ORG 0200H
    CLR 0CFH                  ; Clear TF2 flag (Timer 2 interrupt flag)
    
    ; === SAVE REGISTERS ===
    PUSH 0E0H                 ; Save ACC (accumulator) on stack
    PUSH 0D0H                 ; Save PSW (program status word) on stack
    
    INC 31H                   ; Increment COUNT (0 to 99)
    
    ; === PWM COMPARISON LOGIC ===
    MOV A, 31H                ; Load COUNT into accumulator
    CLR C                     ; Clear carry flag for subtraction
    SUBB A, 30H               ; Subtract DUTY from COUNT (COUNT - DUTY)
    JNC LOW_OUT               ; If COUNT >= DUTY, jump to LOW_OUT
    
    ; COUNT < DUTY -> Output HIGH (active part of PWM pulse)
    SETB 90H                  ; Set P1.0 = 1 (output high)
    SJMP CHECK_PERIOD         ; Skip to period check
    
LOW_OUT:
    ; COUNT >= DUTY -> Output LOW (inactive part of PWM pulse)
    CLR 90H                   ; Clear P1.0 = 0 (output low)
    
CHECK_PERIOD:
    MOV A, 31H                ; Load COUNT into accumulator
    CJNE A, #100, EXIT_ISR    ; If COUNT != 100, skip reset
    MOV 31H, #0               ; Reset COUNT to 0 (start new period)
    
EXIT_ISR:
    ; === RESTORE REGISTERS ===
    POP 0D0H                  ; Restore PSW from stack
    POP 0E0H                  ; Restore ACC from stack
    RETI                      ; Return from interrupt

; ============================================
; BUTTON PLUS INTERRUPT SERVICE ROUTINE
; Triggered by INT0 (P3.2) on falling edge (button press)
; Increases STEP by 1 (from 0 to 3 maximum)
; ============================================
;org button plus duty
ORG 0300H
    PUSH 0E0H                 ; Save ACC on stack (0E0H accumulator address)
    PUSH 0D0H                 ; Save ProgramStatusWord on stack
    
    MOV A, 32H                ; Load current STEP value
    CJNE A, #3, INC_STEP      ; If STEP < 3, increment it
    SJMP EXIT_PLUS            ; If STEP = 3, do nothing (maximum reached)
    
INC_STEP:
    INC 32H                   ; STEP = STEP + 1
    
EXIT_PLUS:
    POP 0D0H                  ; Restore PSW from stack
    POP 0E0H                  ; Restore ACC from stack
    RETI                      ; Return from interrupt

; ============================================
; BUTTON MINUS INTERRUPT SERVICE ROUTINE
; Triggered by INT1 (P3.3) on falling edge (button press)
; Decreases STEP by 1 (from 3 down to 0)
; ============================================

;org button minus duty
ORG 0400H
    PUSH 0E0H                 ; Save ACC on stack
    PUSH 0D0H                 ; Save PSW on stack
    
    MOV A, 32H                ; Load current STEP value
    CJNE A, #0, DEC_STEP      ; If STEP > 0, decrement it
    SJMP EXIT_MINUS           ; If STEP = 0, do nothing (minimum reached)
    
DEC_STEP:
    DEC 32H                   ; STEP = STEP - 1
    
EXIT_MINUS:
    POP 0D0H                  ; Restore PSW from stack
    POP 0E0H                  ; Restore ACC from stack
    RETI                      ; Return from interrupt

END