$MOD51

org 00h

mov dptr, #0C00h       ; load starting address 0C00h into DPTR
mov r2, #04h           ; page counter (4 pages ? 256 = 1024 bytes = 1 Kbyte)
mov p1, #0FFh          ; turn off LEDs (all pins high)

page_loop:
    mov r1, #00h       ; byte counter within page (0-255)

byte_loop:
    mov a, #33h        ; load test pattern 33h into accumulator
    movx @dptr, a      ; write test pattern to external memory (XRAM)
    movx a, @dptr      ; read back from external memory
    xrl a, #33h        ; XOR read value with test pattern (result = 0 if equal)
    jnz error          ; if result != 0, jump to error (memory error detected)

    inc dptr           ; increment DPTR to next memory address
    djnz r1, byte_loop ; decrement R1, jump to byte_loop if not zero (continue within page)
    
    djnz r2, page_loop ; decrement R2, jump to page_loop if not zero (next page)
    
    sjmp complete      ; all tests passed, jump to complete

error:
    clr p1.1           ; turn on LED on P1.1 (error indicator)
    sjmp stop          ; jump to stop

complete:
    clr p1.0           ; turn on LED on P1.0 (success indicator)
    sjmp stop          ; jump to stop

stop:
    END                ; end of program