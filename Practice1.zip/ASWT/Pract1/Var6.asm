$MOD51
	
org 00h 
mov dptr,#400h ; start

mov r2, #08h ; pages counter
mov r3, #00h ; cycle counter

mov p1, #0FFh ;svet

page:
	mov r3, #00h ; start = 0

byte:
	mov a, #0AAh ; VAA = AA
	movx @dptr, a ; XRAM = AA
	movx a, @dptr ;VAA = XRAM
	xrl a, #0AAh ; VAA xor XRAM
	jnz error ; VAA xor XRAM != 0 -> error

	inc dptr ; dptr++

	djnz r3, byte ; 
	djnz r2, page
error:

    clr p1, #0FBh     
    sjmp $         

END	
